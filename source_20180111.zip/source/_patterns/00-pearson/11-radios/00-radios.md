---
title: Radio Buttons
state: uikit
---

Radio buttons are for times when the user needs to make a single choice among many options. Unlike a select box, all options are available and visible to all users at once.
