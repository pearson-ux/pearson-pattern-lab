---
title: Select
state: uikit
---

Select dropdowns are generally meant for times when a user needs to make a single choice from among many options. People can choose more than one option if the mutliple attribute is added, however checkboxes are much more user-friendly for multiple selections.
