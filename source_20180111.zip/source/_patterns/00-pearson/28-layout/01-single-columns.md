---
title: Single columns
state: uikit
---

Prefer to center single column content zones.
