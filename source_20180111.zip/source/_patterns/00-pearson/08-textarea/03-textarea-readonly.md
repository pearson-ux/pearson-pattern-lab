---
title: Basic Readonly Textarea
state: elements
---

This is a basic textarea error in a readonly state
