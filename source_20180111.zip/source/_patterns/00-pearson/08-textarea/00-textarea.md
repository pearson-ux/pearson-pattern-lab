---
title: Basic Textarea
state: uikit
---

This is a basic textarea
