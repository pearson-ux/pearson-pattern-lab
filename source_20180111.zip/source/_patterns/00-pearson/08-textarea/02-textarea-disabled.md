---
title: Basic Disabled Textarea
state: elements
---

This is a basic textarea error in a disabled state
