---
title: Tab navigation responsive mode
state: uikit
---
