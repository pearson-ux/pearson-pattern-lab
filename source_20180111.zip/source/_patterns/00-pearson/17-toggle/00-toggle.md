---
title: Toggle
state: uikit
---

Used to invoke a toggle switch.