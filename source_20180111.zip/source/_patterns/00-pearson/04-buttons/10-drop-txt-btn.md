---
title: Dropdown Button
state: uikit
---

This button is to be used only with a dropdown menu.  It has all the necessary accessibility tags built in.
