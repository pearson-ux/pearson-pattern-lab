---
title: Primary Button
state: uikit
---

Primary button indicates the main call to action and should only appear once per group of buttons.

