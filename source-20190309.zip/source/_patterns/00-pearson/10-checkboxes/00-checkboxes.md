---
title: Checkboxes
state: uikit
---

Checkboxes are for times when the user needs to make one or more binary choices about a related item.
