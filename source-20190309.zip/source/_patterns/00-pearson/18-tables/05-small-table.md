---
title: Small Table
state: elements
---

Every instance of a static table should use this component. For more complex tables with sorting, filtering, etc. see the Interactive Table component.