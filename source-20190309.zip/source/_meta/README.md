This is the default location to place meta files, otherwise known a pattern's header and footer.

Pattern Lab builds each pattern while prepending and appending the header and footer. Read more about [pattern headers and footers](http://patternlab.io/docs/pattern-header-footer.html).

If you wish to rename this directory, make sure you update the `paths.source.meta` property within `patternlab-config.json`.
