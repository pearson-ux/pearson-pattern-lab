This is the default location to place annotations.

Pattern Lab uses annotations defined here to markup the UI. Read more about [annotations](http://patternlab.io/docs/pattern-adding-annotations.html).

If you wish to rename this directory, make sure you update the `paths.source.annotations` property within `patternlab-config.json`.
