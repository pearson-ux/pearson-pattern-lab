This is the default location to place pattern files.

Pattern Lab builds patterns and the ui from the structure defined within. Read more about [pattern organization](http://patternlab.io/docs/pattern-organization.html).

If you wish to rename this directory, make sure you update the `paths.source.patterns` property within `patternlab-config.json`.
