---
title: Button Sizes
state: elements
---

There are three sizes of buttons:

1.Small: Only the default button style is available in this size.

2.Large (Standard): This is the default size. Use this size for touch devices to meet accessibility requirements.

3.Extra Large

