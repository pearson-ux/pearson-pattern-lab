---
title: UI Kit Text - Prototype
state: inprogress
---

Secondary color styles, set in Medium Gray, are part of elements but are not part of the UI Kit. 