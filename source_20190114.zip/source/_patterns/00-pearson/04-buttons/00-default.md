---
title: Default Button
state: uikit
---

Default button is your basic button, it can appear multiple times in a given group.

