---
title: Tertiary Button
state: uikit
---

Tertiary button is for reduced importance actions which should be de-emphasized compared to the default button type.