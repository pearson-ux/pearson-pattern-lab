---
title: Tab navigation dark mode
state: uikit
---
