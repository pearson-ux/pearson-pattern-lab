---
title: Loader Dark
state: uikit
---

A loading indicator provides visual feedback to users that they have initiated a process and it holds their attention for processes that take longer than one second.