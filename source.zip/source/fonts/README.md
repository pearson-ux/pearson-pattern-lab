This is the default location to place global font files.

The entire contents of this directory will be recursively copied to your configured `public/` directory.

If you wish to rename this directory, make sure you update the `paths.source.fonts` property within `patternlab-config.json`.
